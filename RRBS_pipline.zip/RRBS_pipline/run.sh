#!/bin/bash -l
  
module load conda3

mkdir -p Logs
snakemake -j 12 --cluster-config /home/zhypan/RRBS/cluster.yaml --cluster "sbatch --exclude=c11-86,c10-69,c11-92,c11-76 -p {cluster.partition} -t {cluster.time} -N {cluster.nodes} -c {cluster.cpus} -J {cluster.name} -o {cluster.output} -e {cluster.output}" -s /home/zhypan/RRBS/Snakefile --configfile config.yaml --latency-wait 120 -p -k --use-conda $@

